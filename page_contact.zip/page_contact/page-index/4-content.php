 <?php
  $url_host = 'http://' . $_SERVER['HTTP_HOST'];
  $pattern_document_root = addcslashes(realpath($_SERVER['DOCUMENT_ROOT']), '\\');
  $pattern_uri = '/' . $pattern_document_root . '(.*)$/';

  preg_match_all($pattern_uri, __DIR__, $matches);
  $url_path = $url_host . $matches[1][0];
  $url_path = str_replace('\\', '/', $url_path);
  ?>

 <style>
   .carousel-indicators .active {
     width: 12px;
     height: 12px;
     margin: 0;
     background-color: #555;
   }

   .carousel-indicators li {
     display: inline-block;
     width: 10px;
     height: 10px;
     margin: 1px;
     text-indent: -999px;
     cursor: pointer;
     background-color: #000\9;
     background-color: #dcdcdc;
     border: 1px solid #fff;
     border-radius: 10px;
   }
 </style>

 <div id="myCarousel" class="carousel slide" data-ride="carousel">
   <!-- Indicators -->
   <ol class="carousel-indicators" style="bottom: -25px;">
     <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
     <li data-target="#myCarousel" data-slide-to="1"></li>
   </ol>

   <!-- Wrapper for slides -->
   <div class="carousel-inner">
     <div class="item active">
       <div class="row">
         <div class="col-md-2">
           <img src="wp-content/themes/page_contact/images/manufacturer/nfl-130x100.png" alt="NFL" class="img-responsive" />
         </div>
         <div class="col-md-2">
           <img src="wp-content/themes/page_contact/images/manufacturer/redbull-130x100.png" alt="RedBull" class="img-responsive" />
         </div>
         <div class="col-md-2">
           <img src="wp-content/themes/page_contact/images/manufacturer/sony-130x100.png" alt="Sony" class="img-responsive" />
         </div>
         <div class="col-md-2">
           <img src="wp-content/themes/page_contact/images/manufacturer/cocacola-130x100.png" alt="Coca Cola" class="img-responsive" />
         </div>
         <div class="col-md-2">
           <img src="wp-content/themes/page_contact/images/manufacturer/burgerking-130x100.png" alt="Burger King" class="img-responsive" />
         </div>
         <div class="col-md-2">
           <img src="wp-content/themes/page_contact/images/manufacturer/canon-130x100.png" alt="Canon" class="img-responsive" />
         </div>
       </div>
     </div>

     <div class="item">
       <div class="row">
         <div class="col-md-2">
           <img src="wp-content/themes/page_contact/images/manufacturer/canon-130x100.png" alt="Canon" class="img-responsive" />
         </div>
         <div class="col-md-2">

           <img src="wp-content/themes/page_contact/images/manufacturer/harley-130x100.png" alt="Harley Davidson" class="img-responsive" />
         </div>
         <div class="col-md-2">
           <img src="wp-content/themes/page_contact/images/manufacturer/disney-130x100.png" alt="Disney" class="img-responsive" />

         </div>
         <div class="col-md-2">
           <img src="wp-content/themes/page_contact/images/manufacturer/disney-130x100.png" alt="Disney" class="img-responsive" />

         </div>
         <div class="col-md-2">
           <img src="wp-content/themes/page_contact/images/manufacturer/starbucks-130x100.png" alt="Starbucks" class="img-responsive" />
         </div>
         <div class="col-md-2">
           <img src="wp-content/themes/page_contact/images/manufacturer/nintendo-130x100.png" alt="Nintendo" class="img-responsive" />
         </div>
       </div>
     </div>
   </div>


 </div>
 </div>