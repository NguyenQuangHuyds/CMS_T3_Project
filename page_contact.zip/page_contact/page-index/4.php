﻿
<?php include $dir_block.'1-content.php'; ?>
<?php include $dir_block.'2-content.php'; ?>
<?php include $dir_block.'3-content.php'; ?>
<?php include $dir_block.'4-content.php'; ?>
