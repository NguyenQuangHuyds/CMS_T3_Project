
<?php
$url_host = 'http://'.$_SERVER['HTTP_HOST'];
$pattern_document_root = addcslashes(realpath($_SERVER['DOCUMENT_ROOT']), '\\');
$pattern_uri = '/' . $pattern_document_root . '(.*)$/';

preg_match_all($pattern_uri, __DIR__, $matches);
$url_path = $url_host . $matches[1][0];
$url_path = str_replace('\\', '/', $url_path);


$uri = $_SERVER['REQUEST_URI'];
$query = $_SERVER['QUERY_STRING'];
$domain = $_SERVER['HTTP_HOST'];
$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$url = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$check = false;
if($url == 'http://localhost:82/wordpress_project/'){
    $check = true;
}
?>
<?php include $dir_block .'008-content.php'; ?>
<div class="row">
    <div class="col-md-8">
        <?php include $dir_block . 'search-content.php'; ?>
    </div>
    <div class="col-md-4">
        <?php include $dir_block . '009-content.php'; ?>
    </div>
</div>
<?php include $dir_block . '014-content.php'; ?>
