<?php
$url_host = 'http://' . $_SERVER['HTTP_HOST'];
$pattern_document_root = addcslashes(realpath($_SERVER['DOCUMENT_ROOT']), '\\');
$pattern_uri = '/' . $pattern_document_root . '(.*)$/';

preg_match_all($pattern_uri, __DIR__, $matches);
$url_path = $url_host . $matches[1][0];
$url_path = str_replace('\\', '/', $url_path);

$uri = $_SERVER['REQUEST_URI'];
$query = $_SERVER['QUERY_STRING'];
$domain = $_SERVER['HTTP_HOST'];
$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$url = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$check = false;
if ($url == 'http://localhost:82/wordpress_project/') {
    $check = true;
}

?>
<!DOCTYPE html>

<html>

<head>
    <title>module contact</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?php echo $url_path ?>/css/bootstrap.min.css" rel="stylesheet" />
    <link href="<?php echo $url_path ?>/css/font-awesome.min.css" rel="stylesheet" />
    <link href="<?php echo $url_path ?>/css/pagecontact.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo $url_path ?>/css/headercontact.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo $url_path ?>/css/trangchu.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo $url_path ?>/css/footercontact.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo $url_path ?>/css/detail.css" rel="stylesheet" type="text/css" />
    <script src="<?php echo $url_path ?>/js/jquery-2.1.4.min.js"></script>
    <script src="<?php echo $url_path ?>/js/bootstrap.min.js"></script>
    <script src="<?php echo $url_path ?>/js/owl.carousel.min.js"></script>
    <script src="<?php echo $url_path ?>/js/331.js"></script>
</head>

<body style="background: url(<?php if($check == false){echo '../';}else{echo '';}?>wp-content/themes/page_contact/images/27.png);">
    <div class="container">
        <div class="wrapper-box" style="border-radius: 5px; background: #fff;box-shadow: 0 0 10px rgba(0, 0, 0, .2);margin: 20px auto;">
            <div class="container-fluid">
                <?php get_header(); ?>
                <div class="row">
                    <div class="col-md-3" style="border-right: 1px solid #eee;">
                        <?php $dir_block . include 'body_contact/003-Categories-Bestsellers.php'; ?>
                        <?php $dir_block . include 'body_contact/004-Categories-Bestsellers.php'; ?>
                        <?php $dir_block . include 'body_contact/005-Categories-Bestsellers.php'; ?>
                        <?php $dir_block . include 'body_contact/006-Categories-Bestsellers.php'; ?>
                        <?php $dir_block . include 'body_contact/007-Categories-Bestsellers.php'; ?>
                    </div>
                    <div class="col-md-9"> <?php $dir_block . include 'page-index/4.php'; ?></div>
                </div>
            </div>
            <?php get_footer(); ?>
        </div>
    </div>
</body>

</html>