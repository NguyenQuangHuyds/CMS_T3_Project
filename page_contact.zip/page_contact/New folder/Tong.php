<?php

$url_host = 'http://' . $_SERVER['HTTP_HOST'];
$pattern_document_root = addcslashes(realpath($_SERVER['DOCUMENT_ROOT']), '\\');
$pattern_uri = '/' . $pattern_document_root . '(.*)$/';

preg_match_all($pattern_uri, __DIR__, $matches);
$url_path = $url_host . $matches[1][0];
$url_path = str_replace('\\', '/', $url_path);

if (!class_exists('lessc')) {
    $dir_block = dirname($_SERVER['SCRIPT_FILENAME']);
    require_once($dir_block . '/libs/lessc.inc.php');
}

$less = new lessc;
$less->compileFile('less/331.less', 'css/331.css');

?>


<!DOCTYPE html>

<html>

<head>
    <title>module 1329</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?php echo $url_path ?>/css/bootstrap.min.css" rel="stylesheet" />
    <link href="<?php echo $url_path ?>/css/font-awesome.min.css" rel="stylesheet" />
    <link href="<?php echo $url_path ?>/css/331.css" rel="stylesheet" type="text/css" />
    <script src="<?php echo $url_path ?>/js/jquery-2.1.4.min.js"></script>
    <script src="<?php echo $url_path ?>/js/bootstrap.min.js"></script>
    <script src="<?php echo $url_path ?>/js/owl.carousel.min.js"></script>
    <script src="<?php echo $url_path ?>/js/331.js"></script>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-md-3" style="border-right: 1px solid #eee;">
            </div>
            <div class="col-md-9">
                <h1> HTC Touch HD</h1>
                <div class="row">
                    <div class="col-md-6">
                        <?php include $dir_block . '/001-content.php'; ?>
                        <?php include $dir_block . '/005-content.php'; ?>
                    </div>
                    <div class="col-md-6">
                        <?php include $dir_block . '/002-content.php'; ?>
                        <?php include $dir_block . '/003-content.php'; ?>
                        <?php include $dir_block . '/004-content.php'; ?>
                        <?php include $dir_block . '/006-content.php'; ?>
                    </div>
                </div>

                <div>
                    <ul class="nav nav-tabs">
                        <li class="active"><a data-toggle="tab" href="#home">Description</a></li>
                        <li><a data-toggle="tab" href="#menu1">Review (1)</a></li>
                    </ul>

                    <div class="tab-content">
                        <div id="home" class="tab-pane fade in active">
                            <?php include $dir_block . '/012-content.php'; ?>
                        </div>
                        <div id="menu1" class="tab-pane fade">
                        <?php include $dir_block . '/013-content.php'; ?>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>
</body>

</html>