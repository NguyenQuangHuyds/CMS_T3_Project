<?php /*template name: Contact*/ ?>
<?php get_template_part('contact'); ?>