<?php /*template name: Detail*/ ?>
<?php get_template_part('detail'); ?>