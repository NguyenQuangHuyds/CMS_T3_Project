<?php
function theme_settup(){
    register_nav_menu('topmenu',__( 'Menu chính' )); //register_nav_menu(id menu,__( ten menu ))
}
add_action('init', 'theme_settup'); //chạy song song với website khi mở website, sau đó ggoi5 tới function theme_settup
