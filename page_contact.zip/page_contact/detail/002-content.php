  <div class="type-002">
      <ul class="list-unstyled description">
          <li><b>Brand:</b> <a href="#"><span itemprop="brand">HTC</span></a></li>
          <li><b>Product Code:</b> <span itemprop="mpn">Product 1</span></li>
          <li><b>Reward Points:</b> 400</li>
          <li><b>Availability:</b> <span style="color:#53af2e; font-weight:bold;">In Stock</span></li>
      </ul>
  </div>