<div class="type-001">
    
    <div class="" style="text-align: center;">
        <div class="left">
            <img width="100%" src="wp-content/themes/page_contact/images/htc_touch_hd_1-500x500" alt="CSS scale" class="zoom image">

        </div>
        <div class="zoom-gallery"><i class="fa fa-search"></i> Click image for Gallery</div>
    </div>


</div>