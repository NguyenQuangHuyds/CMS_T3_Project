<div class="type-003">
  <div class="before-price">
    <ul >
      <li class="price-div"><span class="price">$122.00</span></li>
      <li>Ex Tax: $100.00</li>
      <li>Price in reward points: 200</li>
    </ul>

  </div>

</div>