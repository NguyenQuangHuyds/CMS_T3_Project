<h1> HTC Touch HD</h1>
<div class="row">
    <div class="col-md-6">
        <?php include $dir_block . '001-content.php'; ?>
        <?php include $dir_block . '005-content.php'; ?>
    </div>
    <div class="col-md-6">
        <?php include $dir_block . '002-content.php'; ?>
        <?php include $dir_block . '003-content.php'; ?>
        <?php include $dir_block . '004-content.php'; ?>
        <?php include $dir_block . '006-content.php'; ?>
    </div>
</div>

<div>
    <ul class="nav nav-tabs">
        <li class="active"><a data-toggle="tab" href="#home">Description</a></li>
        <li><a data-toggle="tab" href="#menu1">Review (1)</a></li>
    </ul>

    <div class="tab-content">
        <div id="home" class="tab-pane fade in active">
            <?php include $dir_block . '012-content.php'; ?>
        </div>
        <div id="menu1" class="tab-pane fade">
            <?php include $dir_block . '013-content.php'; ?>
        </div>
    </div>
</div>
