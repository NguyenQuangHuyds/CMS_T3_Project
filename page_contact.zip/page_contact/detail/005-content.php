<div class="type-005">
    <div class="thumbnail-all">
        <a class="thumbnail" href="#" title="HTC Touch HD"> <img src="wp-content/themes/page_contact/images/htc_touch_hd_1-500x500" title="HTC Touch HD" alt="HTC Touch HD" /></a>
        <a class="thumbnail" href="#" data-zoom-image="" title="HTC Touch HD"><img src="wp-content/themes/page_contact/images/htc_touch_hd_1-500x500" title="HTC Touch HD" alt="HTC Touch HD" /></a>
        <a class="thumbnail" href="#" data-zoom-image="" data-image="" title="HTC Touch HD"><img src="wp-content/themes/page_contact/images/htc_touch_hd_1-500x500" title="HTC Touch HD" alt="HTC Touch HD" /></a>
    </div>
</div>