 <div class="type-013">
   <div class="tab-pane" id="tab-review">
     <form style="height: 513px;" class="form-horizontal" id="form-review">
       <div id="review">
         <div>
           <table class="table table-striped table-bordered">
             <tbody>
               <tr>
                 <td style="width: 50%;"><strong><span>labic</span></strong></td>
                 <td class="text-right"><span>06/09/2015</span></td>
               </tr>
               <tr>
                 <td colspan="2">
                   <p>orem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                   <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                     <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                     <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                     <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                     <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
                   </div>
                 </td>
               </tr>
             </tbody>
           </table>
         </div>
       </div>
       <h2>Write a review</h2>
       <div class="form-group required">
         <div class="col-sm-12">
           <label class="control-label" for="input-name">Your Name</label>
           <input type="text" name="name" value="" id="input-name" class="form-control" />
         </div>
       </div>
       <div class="form-group required">
         <div class="col-sm-12">
           <label class="control-label" for="input-review">Your Review</label>
           <textarea name="text" rows="5" id="input-review" class="form-control"></textarea>
           <div class="help-block"><span class="text-danger">Note:</span> HTML is not translated!</div>
         </div>
       </div>
       <div class="form-group required">
         <div class="col-sm-12">
           <label class="control-label">Rating</label>
           &nbsp;&nbsp;&nbsp; Bad&nbsp;
           <input type="radio" name="rating" value="1" />
           &nbsp;
           <input type="radio" name="rating" value="2" />
           &nbsp;
           <input type="radio" name="rating" value="3" />
           &nbsp;
           <input type="radio" name="rating" value="4" />
           &nbsp;
           <input type="radio" name="rating" value="5" />
           &nbsp;Good</div>
       </div>
       <div class="buttons pull-right">
         <button type="button" id="button-review" data-loading-text="Loading..." class="btn btn-primary">Continue</button>

       </div>
     </form>
   </div>
 </div>