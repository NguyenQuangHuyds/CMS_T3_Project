<div class="row">
    <column class="col-sm-3" style="border-right: 1px solid #eee;">
        <?php $dir_block . include '007-Categories-Bestsellers.php'; ?>
        <?php $dir_block . include '005-Categories-Bestsellers.php'; ?>
    </column>
    <div class="col-sm-9">
        <?php $dir_block . include '001-contact.php'; ?>
        <?php $dir_block . include '002-contact.php'; ?>
    </div>
</div>