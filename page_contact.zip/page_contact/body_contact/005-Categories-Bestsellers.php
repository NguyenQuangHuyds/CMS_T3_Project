<?php
$url_host = 'http://' . $_SERVER['HTTP_HOST'];
$pattern_document_root = addcslashes(realpath($_SERVER['DOCUMENT_ROOT']), '\\');
$pattern_uri = '/' . $pattern_document_root . '(.*)$/';

preg_match_all($pattern_uri, __DIR__, $matches);
$url_path = $url_host . $matches[1][0];
$url_path = str_replace('\\', '/', $url_path);


?>

<div class="type-005-Categories-Bestsellers">
    <div id="bigshop-banner0" class="bigshop-banner">
        <div class="row">
          
                 <?php
                 $args = array(
                        'post_status' => 'publish', // Chỉ lấy những bài viết được publish
                        
                    );
                ?>
                <?php $getposts = new WP_query($args); ?>
                <?php global $wp_query; $wp_query->in_the_loop = true; ?>
                <?php while ($getposts->have_posts()) : $getposts->the_post(); ?>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 moderns " style="text-align: center;margin-bottom: 0;">
                 <div style="background: #f5b5a9 !important; padding: 10px;">
                <a href="" style="text-decoration: none; color:#000">
                        <h3><?php echo the_title();?></h3>
                        <p><?php the_content(); // lấy toàn bộ nội dung bài post ?></p>
                    </a>
                    </div>
                </div>
                
                <?php endwhile; wp_reset_postdata(); 
                ?>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 moderns " style="text-align: center;">
                    <img width="100%" src="<?php if($check == false){echo '../';}else{echo '';}?>wp-content/themes/page_contact/images/sb2-262x125.jpg" alt="">
                </div>

                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 moderns " style="text-align: center;">
                    <img width="100%" src="<?php if($check == false){echo '../';}else{echo '';}?>wp-content/themes/page_contact/images/sb3-262x125.jpg" alt="">
                </div>
                
        </div>
    </div>
</div>